'use strict'
import { get } from 'request';

/**
 * @param event - API Gateway Lambda Proxy Input
 * @param context - 
 * @returns - City names of each long, lat pair
 */
export function handler (event, context, callback) {
    const url = "http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/reverseGeocode?f=pjson&location="
    const bodyData = JSON.parse(event.body)
    const coordinatesList = bodyData["list"]

    var reverseGelocateCall = function(coordinates){

        var options = {
            url: url + coordinates["lat"] + coordinates["long"],
            headers: {
                'User-Agent': 'request'
            }       
        };

        return new Promise(function(resolve, reject){
            get(options, function(err, response, body){
                if (err){
                    reject(err);
                } else {
                    resolve (JSON.parse(body))
                }
            })
        })
    }

    var actions = coordinatesList.map(reverseGelocateCall);
    Promise.all(actions).then(
        function(data){
            console.log(data)
        }
    ).then(callback(null, {
        "results":data
    }))

    
}